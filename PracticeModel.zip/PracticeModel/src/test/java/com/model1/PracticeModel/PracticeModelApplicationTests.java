package com.model1.PracticeModel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticeModelApplicationTests {

	@Test
	void contextLoads() {
	}

}
